package com.example.kedirilagi;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class SejarahAdapter extends RecyclerView.Adapter<SejarahAdapter.MyViewHolder> {

    Context mContext;
    List<Sejarahs> mData;

    public SejarahAdapter(Context mContext, List<Sejarahs> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View row = LayoutInflater.from(mContext).inflate(R.layout.row_item,parent,false);
        return new MyViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.tvNama.setText(mData.get(position).getNama());
        holder.tvOpen.setText(mData.get(position).getOpen());
        Glide.with(mContext).load(mData.get(position).getPicture()).into(holder.image);


    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        Button btDetail;
        TextView tvNama;
        TextView tvOpen;
        ImageView image;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvNama = itemView.findViewById(R.id.tvNama);
            tvOpen = itemView.findViewById(R.id.tvOpen);
            image = itemView.findViewById(R.id.img);
            btDetail = itemView.findViewById(R.id.btDetail);
            btDetail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent sejarahDetailActivity = new Intent(mContext, SejarahDetailActivity.class);
                    int position = getAdapterPosition();

                    sejarahDetailActivity.putExtra("nama",mData.get(position).getNama());
                    sejarahDetailActivity.putExtra("sejarahImage",mData.get(position).getPicture());
                    sejarahDetailActivity.putExtra("description",mData.get(position).getDescription());
                    sejarahDetailActivity.putExtra("alamat",mData.get(position).getAlamat());
                    sejarahDetailActivity.putExtra("htm",mData.get(position).getHtm());
                    sejarahDetailActivity.putExtra("open",mData.get(position).getOpen());
                    sejarahDetailActivity.putExtra("highlight",mData.get(position).getHighlight());
                    sejarahDetailActivity.putExtra("sejarahKey",mData.get(position).getSejarahKey());
                    mContext.startActivity(sejarahDetailActivity);
                }
            });

        }
    }
}