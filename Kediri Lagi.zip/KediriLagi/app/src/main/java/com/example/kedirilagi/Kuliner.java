package com.example.kedirilagi;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Kuliner extends AppCompatActivity {

    RecyclerView kulinerRecyclerView;
    KulinerAdapter kulinerAdapter;
    EditText InputSearch;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    List<Kuliners> kulinerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alam);

        InputSearch = findViewById(R.id.InputSearch);
        InputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.toString()!=null)
                {
                    search(s.toString());
                }
                else
                {
                    search("");
                }
            }
        });

        kulinerRecyclerView = findViewById(R.id.AlamRV);
        kulinerRecyclerView.setLayoutManager(new LinearLayoutManager(Kuliner.this));
        kulinerRecyclerView.setHasFixedSize(true);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Kuliner");

    }

    private void search(String toString){
        Query query = databaseReference.orderByChild("nama")
                .startAt(toString)
                .endAt(toString + "\uf8ff");

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.hasChildren()){
                    kulinerList.clear();
                    for (DataSnapshot dss: dataSnapshot.getChildren()){
                        final Kuliners kuliners = dss.getValue(Kuliners.class);
                        kuliners.setKulinerKey(dss.getKey());
                        kulinerList.add(kuliners);
                    }

                    kulinerAdapter = new KulinerAdapter(Kuliner.this,kulinerList);
                    kulinerRecyclerView.setAdapter(kulinerAdapter);
                    kulinerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        //Get list Alam from the database

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                kulinerList = new ArrayList<>();
                for (DataSnapshot kulinersnap: dataSnapshot.getChildren()){

                    Kuliners kuliners = kulinersnap.getValue(Kuliners.class);
                    kuliners.setKulinerKey(kulinersnap.getKey());
                    kulinerList.add(kuliners);

                }

                kulinerAdapter = new KulinerAdapter(Kuliner.this,kulinerList);
                kulinerRecyclerView.setAdapter(kulinerAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}

