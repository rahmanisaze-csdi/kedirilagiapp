package com.example.kedirilagi;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class PasarAdapter extends RecyclerView.Adapter<PasarAdapter.MyViewHolder> {

    Context mContext;
    List<Pasars> mData;

    public PasarAdapter(Context mContext, List<Pasars> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View row = LayoutInflater.from(mContext).inflate(R.layout.row_item,parent,false);
        return new MyViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.tvNama.setText(mData.get(position).getNama());
        holder.tvOpen.setText(mData.get(position).getOpen());
        Glide.with(mContext).load(mData.get(position).getPicture()).into(holder.image);


    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        Button btDetail;
        TextView tvNama;
        TextView tvOpen;
        ImageView image;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvNama = itemView.findViewById(R.id.tvNama);
            tvOpen = itemView.findViewById(R.id.tvOpen);
            image = itemView.findViewById(R.id.img);
            btDetail = itemView.findViewById(R.id.btDetail);
            btDetail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent pasarDetailActivity = new Intent(mContext, PasarDetailActivity.class);
                    int position = getAdapterPosition();

                    pasarDetailActivity.putExtra("nama", mData.get(position).getNama());
                    pasarDetailActivity.putExtra("pasarImage", mData.get(position).getPicture());
                    pasarDetailActivity.putExtra("description", mData.get(position).getDescription());
                    pasarDetailActivity.putExtra("alamat", mData.get(position).getAlamat());
                    pasarDetailActivity.putExtra("open", mData.get(position).getOpen() );
                    pasarDetailActivity.putExtra("pasarKey", mData.get(position).getPasarKey());
                    mContext.startActivity(pasarDetailActivity);
                }
            });

        }
    }
}

