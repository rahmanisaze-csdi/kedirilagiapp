package com.example.kedirilagi;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

public class Home extends AppCompatActivity {
    Button b1,b2,b3,b4,b5,b6;
    VideoView v1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
        b1=(Button)findViewById(R.id.btAlam);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Home.this,Alam.class);
                startActivity(i);
            }
        });
        b2=(Button)findViewById(R.id.btSejarah);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(Home.this,Sejarah.class);
                startActivity(a);
            }
        });
        b3=(Button)findViewById(R.id.btReligi);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent b = new Intent(Home.this,Religi.class);
                startActivity(b);
            }
        });
        b4=(Button)findViewById(R.id.btKuliner);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent c = new Intent(Home.this,Kuliner.class);
                startActivity(c);
            }
        });
        b5=(Button)findViewById(R.id.btPasar);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent d = new Intent(Home.this,Pasar.class);
                startActivity(d);
            }
        });
        b6=(Button)findViewById(R.id.btCafe);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent e = new Intent(Home.this,Cafe.class);
                startActivity(e);
            }
        });
        v1=(VideoView)findViewById(R.id.videoku);
        String path = "android.resource://com.example.kedirilagi/"+R.raw.kediriku_20200720_181028_0;
        Uri uri = Uri.parse(path);
        v1.setVideoURI(uri);
        v1.start();

        v1.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setLooping(true);
            }
        });

    }

    @Override
    protected void onResume(){
        v1.resume();
        super.onResume();
    }

    @Override
    protected void onPause(){
        v1.suspend();
        super.onPause();
    }

    @Override
    protected void onDestroy(){
        v1.stopPlayback();
        super.onDestroy();
    }
}
